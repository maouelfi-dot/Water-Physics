package com.oceanphysics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class WaveConfig {
    public enum Size {
        SMALL(0.4), MEDIUM(0.9), LARGE(1.5), HUGE(2.4), EPIC(3.4);
        public final double amplitude;
        Size(double a) { this.amplitude = a; }
    }

    public int configVersion = 9;

    public boolean enabled = true;
    public Size waveSize = Size.HUGE;       // SMALL / MEDIUM / LARGE / HUGE / EPIC (tinggi ombak maksimum)
    public double waveLength = 56.0;        // panjang gelombang terbesar (blok); kecil = ombak lebih curam dan rapat
    public double waveSpeed = 0.8;          // pengali kecepatan ombak
    public double windAngleDegrees = 35.0;  // arah angin utama
    public long seed = 1337L;               // samakan di server dan semua pemain
    public double fullDepth = 6.0;          // kedalaman air agar ombak penuh (blok)

    public double chop = 1.2;               // 0 = ombak bulat, makin besar puncak makin tajam (ombak pecah)
    public double minDepthFactor = 0.15;    // ombak minimum di air dangkal/kolam (0..1)

    // badai: hujan/petir membuat ombak makin tinggi, pendek-pendek, dan galak (server + client, dari cuaca dunia)
    public boolean stormWaves = true;
    public double stormWaveBoost = 1.5;     // tinggi ombak x(1 + boost) saat badai petir penuh
    public double stormChoppy = 1.5;        // ombak pendek/kasar makin kuat saat badai

    // arus ombak nyata: benda ikut kecepatan partikel air (orbital + drift Stokes), bukan sekadar naik-turun
    public boolean waterCurrent = true;
    public double currentStrength = 1.0;    // pengali arus ombak untuk semua benda
    public boolean shoreSurge = true;       // ombak menghempas ke pantai lalu menarik kembali (undertow)
    public double surgeStrength = 1.0;
    public double stokesDrift = 1.0;        // hanyut bersih searah ombak
    public boolean extendedWet = true;      // benda di dalam badan ombak (di atas air vanila) tetap dianggap di air

    // kapal: badan kaku pegas-peredam (pitch/roll) + naik-turun dari 5 titik
    public boolean boatRig = true;
    public double boatRockStiffness = 0.016; // kekakuan pegas (per tick^2)
    public double boatRockDamping = 0.07;    // redaman (makin kecil makin lama bergoyang)

    // ombak menyapu blok rapuh di tepi air (obor, bunga, tebu, redstone, dll.) saat badai
    public boolean washAway = true;
    public double washStormMin = 0.55;      // level badai minimum (0..1)
    public int washPerSecond = 6;           // sampel acak per detik per pemain (kecil = ringan)

    // pohon roboh saat ditebang
    public boolean treeFall = true;
    public int treeMaxLogs = 400;           // batang lebih banyak dari ini dianggap bangunan, bukan pohon
    public int treeMaxBlocks = 380;         // maks balok (batang + daun) yang ikut roboh sebagai satu pohon
    public int treeMinLeaves = 3;           // minimal daun alami agar dianggap pohon (rumah kayu aman)
    public double treeFallSpeed = 1.0;      // pengali kecepatan roboh (besar = lebih cepat)

    // visual badai/matahari
    public boolean glare = true;            // pantulan matahari/bulan di air (silau)
    public double glareStrength = 0.6;
    public boolean stormTint = true;        // air jadi gelap kelabu saat badai
    public boolean spray = true;            // semprotan di puncak ombak saat badai
    public int spraySamples = 4;

    // fisika air total (server): ganti logika aliran vanila, air bermassa terbatas
    public boolean realFluid = true;
    public int realFluidPerTick = 500;      // maks sel air diproses per tick (kecil = ringan, air lebih lambat)

    // aliran air nyata (server): air vanilla mengalir lebih cepat dan lebih jauh
    public boolean fastFlow = true;
    public int flowTickRate = 2;            // vanilla 5; makin kecil makin cepat mengalir/tumpah
    public int flowDistance = 8;            // vanilla 4; jarak air mencari lubang/turunan

    // air tumpah (simulasi cairan partikel, client): ember air -> genangan yang mengalir
    public boolean spill = true;
    public boolean spillAlways = false;     // false = hanya saat Sneak + klik kanan ember air; true = selalu tumpah
    public int spillMax = 450;              // maks partikel (kecil = ringan)
    public int spillPerBucket = 260;        // partikel per ember
    public int spillLifeSeconds = 18;       // lama genangan sebelum meresap

    // kapal
    public boolean boatTilt = true;
    public double boatFollowStrength = 1.0; // 0 = mati, 1 = normal
    public double boatSlide = 0.012;        // dorongan menuruni lereng ombak
    public double boatRestDepth = 0.366;    // seberapa dalam lambung duduk di bawah garis air (vanila = 0.366)
    public double boatLift = 0.0;           // geser naik/turun kapal manual (blok); + = lebih tinggi
    public double boatVerticalFollow = 0.5; // kecepatan kapal mengejar tinggi ombak (0.1 lambat .. 1.0 instan)

    // pemain, mob, item, pancing
    public boolean swimBobbing = true;
    public boolean mobBobbing = true;
    public boolean itemBobbing = true;
    public boolean itemPhysics = true;      // item tergeletak rata di tanah, berputar di udara, memantul
    public boolean itemBounce = true;       // item memantul saat jatuh keras
    public boolean sneakPickup = true;      // item hanya bisa diambil saat pemain jongkok (Sneak) di dekatnya
    public boolean itemSinking = true;      // item berat (besi, batu, dll.) tenggelam, item ringan (kayu) mengapung
    public boolean fallingBlockDrag = true; // pasir/kerikil melambat di air
    public boolean splashShock = true;      // benda jatuh ke air mendorong benda terapung di sekitarnya
    public boolean playerFloat = true;      // pemain mengapung di permukaan saat diam (tahan Sneak untuk turun)
    public double swellStrength = 1.0;      // pengali gaya ombak pada pemain/mob/item

    // permukaan air (visual, client)
    public boolean renderWaterMesh = true;
    public boolean meshWithShaders = true;  // gambar juga saat shader Iris aktif
    public int meshRadius = 44;             // jari-jari (blok); kecil = ringan
    public int meshCell = 2;                // ukuran sel (blok); 1 = lebih halus tapi lebih berat
    public double meshLift = 0.0025;        // angkat lapisan per blok jarak (mencegah kedip/z-fighting di HP)
    public int meshAlpha = 205;             // 0..255 transparansi lapisan air

    // riak (simulasi persamaan gelombang 2D, client)
    public boolean ripples = true;
    public double rippleStrength = 1.2;     // kekuatan riak dari gerakan
    public double rippleSpeed = 0.28;       // 0.05..0.45 (kecepatan rambat)
    public double rippleDamping = 0.99;    // 0.95..0.995 (makin kecil makin cepat hilang)
    public boolean rainRipples = true;

    // busa
    public boolean foam = true;
    public int foamSamples = 5;
    public double foamRadius = 24.0;
    public double foamIntensity = 0.8;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static WaveConfig INSTANCE = new WaveConfig();

    public static WaveConfig get() { return INSTANCE; }

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("oceanphysics.json");
        try {
            if (Files.exists(p)) {
                WaveConfig c = GSON.fromJson(Files.readString(p), WaveConfig.class);
                // config lama (versi < 2) dibuang supaya default baru berlaku
                if (c != null && c.configVersion >= 9) { INSTANCE = c; INSTANCE.configVersion = 9; }
            }
            Files.writeString(p, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            OceanPhysicsMod.LOGGER.error("Gagal memuat config", e);
        }
        INSTANCE.meshCell = Math.max(1, Math.min(4, INSTANCE.meshCell));
        if (INSTANCE.waveSize == null) INSTANCE.waveSize = Size.HUGE;
        INSTANCE.waveLength = Math.max(16.0, Math.min(200.0, INSTANCE.waveLength));
        INSTANCE.meshLift = Math.max(0.0, Math.min(0.02, INSTANCE.meshLift));
        INSTANCE.treeMaxBlocks = Math.max(20, Math.min(1200, INSTANCE.treeMaxBlocks));
        INSTANCE.treeMaxLogs = Math.max(8, Math.min(1200, INSTANCE.treeMaxLogs));
        INSTANCE.treeMinLeaves = Math.max(0, Math.min(50, INSTANCE.treeMinLeaves));
        INSTANCE.treeFallSpeed = Math.max(0.3, Math.min(3.0, INSTANCE.treeFallSpeed));
        INSTANCE.meshRadius = Math.max(8, Math.min(60, INSTANCE.meshRadius));
        INSTANCE.flowTickRate = Math.max(1, Math.min(20, INSTANCE.flowTickRate));
        INSTANCE.flowDistance = Math.max(1, Math.min(12, INSTANCE.flowDistance));
        INSTANCE.minDepthFactor = Math.max(0.0, Math.min(1.0, INSTANCE.minDepthFactor));
        INSTANCE.rippleSpeed = Math.max(0.05, Math.min(0.45, INSTANCE.rippleSpeed));
        INSTANCE.rippleDamping = Math.max(0.9, Math.min(0.998, INSTANCE.rippleDamping));
        INSTANCE.stormWaveBoost = Math.max(0.0, Math.min(5.0, INSTANCE.stormWaveBoost));
        INSTANCE.stormChoppy = Math.max(0.0, Math.min(6.0, INSTANCE.stormChoppy));
        INSTANCE.currentStrength = Math.max(0.0, Math.min(6.0, INSTANCE.currentStrength));
        INSTANCE.surgeStrength = Math.max(0.0, Math.min(6.0, INSTANCE.surgeStrength));
        INSTANCE.boatRestDepth = Math.max(0.0, Math.min(0.6, INSTANCE.boatRestDepth));
        INSTANCE.boatLift = Math.max(-0.5, Math.min(0.5, INSTANCE.boatLift));
        INSTANCE.boatVerticalFollow = Math.max(0.1, Math.min(1.0, INSTANCE.boatVerticalFollow));
        INSTANCE.boatRockStiffness = Math.max(0.002, Math.min(0.06, INSTANCE.boatRockStiffness));
        INSTANCE.boatRockDamping = Math.max(0.01, Math.min(0.3, INSTANCE.boatRockDamping));
        INSTANCE.washPerSecond = Math.max(0, Math.min(40, INSTANCE.washPerSecond));
        INSTANCE.spraySamples = Math.max(0, Math.min(16, INSTANCE.spraySamples));
        WaveMath.init(INSTANCE.seed);
    }
}
