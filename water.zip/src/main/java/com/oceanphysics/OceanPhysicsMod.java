package com.oceanphysics;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OceanPhysicsMod implements ModInitializer {
    public static final String MOD_ID = "oceanphysics";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        WaveConfig.load();
        FallingTreeEntity.TYPE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "falling_tree"),
                EntityType.Builder.<FallingTreeEntity>create(FallingTreeEntity::new, SpawnGroup.MISC)
                        .dimensions(0.5f, 0.5f).maxTrackingRange(10).trackingTickInterval(1).build("falling_tree"));
        TreeFelling.register();
        LOGGER.info("Ocean Physics v9 dimuat. Ukuran ombak: {}", WaveConfig.get().waveSize);
    }
}
