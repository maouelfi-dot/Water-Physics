package com.oceanphysics;

import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;

/**
 * Pohon tumbang ala Panda's Trees: tebang satu batang pohon -> seluruh batang di atasnya + semua daunnya
 * rebah UTUH menjauhi pemain (FallingTreeEntity), baru hancur dan menjatuhkan semua drop saat menyentuh tanah.
 * Hanya dianggap pohon bila ada cukup daun alami (rumah kayu aman).
 */
public final class TreeFelling {
    private TreeFelling() {}

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register(TreeFelling::onBreak);
    }

    private static void onBreak(World w, PlayerEntity pl, BlockPos pos, BlockState state, BlockEntity be) {
        WaveConfig cfg = WaveConfig.get();
        if (!(w instanceof ServerWorld sw) || !cfg.treeFall || !state.isIn(BlockTags.LOGS)) return;
        try {
            fell(sw, pl, pos);
        } catch (Throwable t) {
            OceanPhysicsMod.LOGGER.error("Pohon tumbang error (dilewati)", t);
        }
    }

    private static void fell(ServerWorld w, PlayerEntity pl, BlockPos origin) {
        WaveConfig cfg = WaveConfig.get();
        ArrayList<BlockPos> logs = new ArrayList<>();
        HashSet<Long> seen = new HashSet<>();
        ArrayList<BlockPos> queue = new ArrayList<>();
        queue.add(origin);
        seen.add(origin.asLong());
        for (int qi = 0; qi < queue.size() && logs.size() < cfg.treeMaxLogs; qi++) {
            BlockPos p = queue.get(qi);
            for (int dx = -1; dx <= 1; dx++) for (int dy = 0; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                BlockPos n = p.add(dx, dy, dz);
                if (Math.abs(n.getX() - origin.getX()) > 12 || Math.abs(n.getZ() - origin.getZ()) > 12
                        || n.getY() - origin.getY() > 58) continue;
                if (!seen.add(n.asLong())) continue;
                if (w.getBlockState(n).isIn(BlockTags.LOGS)) {
                    logs.add(n);
                    queue.add(n);
                }
            }
        }
        if (logs.isEmpty()) return;

        // daun: semua daun alami yang tersambung ke batang (rambat lewat daun)
        ArrayList<BlockPos> leaves = new ArrayList<>();
        HashSet<Long> seenL = new HashSet<>();
        ArrayList<BlockPos> lq = new ArrayList<>(logs);
        for (int qi = 0; qi < lq.size() && leaves.size() < cfg.treeMaxLeaves; qi++) {
            BlockPos p = lq.get(qi);
            for (Direction d : Direction.values()) {
                BlockPos n = p.offset(d);
                if (Math.abs(n.getX() - origin.getX()) > 12 || Math.abs(n.getZ() - origin.getZ()) > 12) continue;
                if (n.getY() < origin.getY()) continue;
                if (!seenL.add(n.asLong())) continue;
                BlockState ns = w.getBlockState(n);
                if (!ns.isIn(BlockTags.LEAVES)) continue;
                if (ns.contains(LeavesBlock.PERSISTENT) && ns.get(LeavesBlock.PERSISTENT)) continue;
                if (ns.contains(LeavesBlock.DISTANCE) && ns.get(LeavesBlock.DISTANCE) > 7) continue;
                leaves.add(n);
                lq.add(n);
            }
        }
        if (leaves.size() < 6) return; // bukan pohon

        double dirX = origin.getX() + 0.5 - pl.getX(), dirZ = origin.getZ() + 0.5 - pl.getZ();
        double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
        if (len < 0.01) { dirX = 1; dirZ = 0; len = 1; }
        dirX /= len;
        dirZ /= len;

        ArrayList<BlockPos> all = new ArrayList<>(logs);
        all.addAll(leaves);
        ArrayList<BlockState> st = new ArrayList<>(all.size());
        for (BlockPos p : all) st.add(w.getBlockState(p));

        FallingTreeEntity e = new FallingTreeEntity(FallingTreeEntity.TYPE, w);
        e.setPosition(origin.getX() + 0.5, origin.getY(), origin.getZ() + 0.5);
        e.setup(origin, all, st, dirX, dirZ, w.getTime());
        for (BlockPos p : all) w.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        w.spawnEntity(e);
    }
}
