package com.oceanphysics;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.List;

/**
 * Pohon tumbang UTUH: semua batang + daun menjadi satu benda yang berputar (rebah) mengitari pangkal tebangan.
 * Server mengecek tabrakan tiap tick; saat batang menyentuh tanah/benda padat (atau sudah 90 derajat)
 * seluruh blok baru hancur dan menjatuhkan drop di posisi akhirnya. Client hanya menganimasikan (sudut dari waktu dunia).
 */
public class FallingTreeEntity extends Entity {
    public static EntityType<FallingTreeEntity> TYPE;
    public static final TrackedData<NbtCompound> DATA =
            DataTracker.registerData(FallingTreeEntity.class, TrackedDataHandlerRegistry.NBT_COMPOUND);

    public int[] rel = new int[0];
    public BlockState[] states = new BlockState[0];
    public double dirX = 1.0, dirZ = 0.0;
    public long t0;

    public FallingTreeEntity(EntityType<?> type, World world) {
        super(type, world);
        this.noClip = true;
        this.setNoGravity(true);
    }

    /** Sudut rebah (derajat) pada t tick sejak mulai: pelan di awal, makin cepat (gravitasi). */
    public static double angleDeg(double t) {
        double a = 0.07 * t * t + 0.4 * t;
        return a > 90.0 ? 90.0 : (a < 0 ? 0 : a);
    }

    public static int pack(int rx, int ry, int rz) {
        return ((rx + 64) & 127) | (((ry + 64) & 127) << 7) | (((rz + 64) & 127) << 14);
    }

    public static int unX(int p) { return (p & 127) - 64; }
    public static int unY(int p) { return ((p >> 7) & 127) - 64; }
    public static int unZ(int p) { return ((p >> 14) & 127) - 64; }

    /** Server: isi data pohon (dipanggil SEBELUM entity dimasukkan ke dunia). */
    public void setup(BlockPos origin, List<BlockPos> pos, List<BlockState> st, double dx, double dz, long startTime) {
        int n = pos.size();
        int[] p = new int[n], s = new int[n];
        for (int i = 0; i < n; i++) {
            BlockPos b = pos.get(i);
            p[i] = pack(b.getX() - origin.getX(), b.getY() - origin.getY(), b.getZ() - origin.getZ());
            s[i] = Block.getRawIdFromState(st.get(i));
        }
        NbtCompound c = new NbtCompound();
        c.putIntArray("p", p);
        c.putIntArray("s", s);
        c.putDouble("dx", dx);
        c.putDouble("dz", dz);
        c.putLong("t", startTime);
        this.getDataTracker().set(DATA, c);
        parse(c);
    }

    private void parse(NbtCompound c) {
        if (!c.contains("p")) return;
        int[] p = c.getIntArray("p"), s = c.getIntArray("s");
        int n = Math.min(p.length, s.length);
        BlockState[] arr = new BlockState[n];
        for (int i = 0; i < n; i++) arr[i] = Block.getStateFromRawId(s[i]);
        this.rel = p.length == n ? p : java.util.Arrays.copyOf(p, n);
        this.states = arr;
        this.dirX = c.getDouble("dx");
        this.dirZ = c.getDouble("dz");
        this.t0 = c.getLong("t");
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(DATA, new NbtCompound());
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (DATA.equals(data)) parse(this.getDataTracker().get(DATA));
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {}

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {}

    @Override
    public boolean shouldSave() {
        return false;
    }

    /** Pusat blok i (koordinat dunia) setelah diputar sudut ang (rad). */
    private double[] center(int i, double ang) {
        int p = rel[i];
        double rx = unX(p), cy = unY(p) + 0.5, rz = unZ(p);
        double dd = rx * dirX + rz * dirZ;
        double px = rx - dd * dirX, pz = rz - dd * dirZ;
        double c = Math.cos(ang), s = Math.sin(ang);
        double nd = dd * c + cy * s, ny = cy * c - dd * s;
        return new double[]{getX() + dirX * nd + px, getY() + ny, getZ() + dirZ * nd + pz};
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient || !(getWorld() instanceof ServerWorld sw)) return;
        if (rel.length == 0) {
            discard();
            return;
        }
        double t = sw.getTime() - t0;
        double deg = angleDeg(t);
        double ang = Math.toRadians(deg);
        boolean hit = deg >= 90.0;
        if (!hit && t >= 2) {
            for (int i = 0; i < rel.length && !hit; i++) {
                if (!states[i].isIn(BlockTags.LOGS)) continue; // hanya batang yang membentur (daun tembus)
                double[] c = center(i, ang);
                BlockPos bp = BlockPos.ofFloored(c[0], c[1], c[2]);
                BlockState bs = sw.getBlockState(bp);
                if (!bs.isAir() && !bs.isIn(BlockTags.LEAVES) && !bs.getCollisionShape(sw, bp).isEmpty()) hit = true;
            }
        }
        if (hit) crash(sw, ang);
    }

    private void crash(ServerWorld sw, double ang) {
        for (int i = 0; i < rel.length; i++) {
            double[] c = center(i, ang);
            BlockPos bp = BlockPos.ofFloored(c[0], c[1], c[2]);
            for (int k = 0; k < 4 && !sw.getBlockState(bp).getCollisionShape(sw, bp).isEmpty(); k++) bp = bp.up();
            BlockState st = states[i];
            Block.dropStacks(st, sw, bp);
            if (i % 3 == 0) sw.syncWorldEvent(2001, bp, Block.getRawIdFromState(st));
        }
        discard();
    }
}
