package com.oceanphysics.client;

import com.oceanphysics.OceanPhysicsMod;
import com.oceanphysics.WaterGrid;
import com.oceanphysics.WaveConfig;
import com.oceanphysics.WaveMath;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Permukaan laut/danau: menggantikan air vanila permukaan (lihat BlockRenderManagerMixin). Dua cincin mesh:
 * dekat (sel 1 blok) dan jauh (sel 4 blok, tanpa gelombang pendek). Tinggi = permukaan vanila + gelombang
 * (naik DAN turun di sekitar permukaan vanila). Digambar lewat layer blok translusen (bukan layer entity).
 * Jika ada error, fitur mati sendiri dan chunk dibangun ulang supaya air vanila kembali.
 */
public final class OceanRenderer {
    public static volatile boolean failed;

    private static final int NEAR_HALF = 28, FAR_HALF = 30;
    private static final WaterGrid NEAR = new WaterGrid(), FAR = new WaterGrid();
    private static final int MAXN = 64;
    private static final float[] ys = new float[MAXN * MAXN], sh = new float[MAXN * MAXN];
    private static final int[] ids = new int[MAXN * MAXN];
    private static final float[] hy = new float[(MAXN + 1) * (MAXN + 1)], hs = new float[(MAXN + 1) * (MAXN + 1)],
            hnx = new float[(MAXN + 1) * (MAXN + 1)], hnz = new float[(MAXN + 1) * (MAXN + 1)];

    private static ClientWorld lastWorld;
    private static long lastTime = Long.MIN_VALUE, lastNano;
    private static int budget;
    private static boolean announced;
    private static float fTint;
    private static final float TINT_R = 52f, TINT_G = 74f, TINT_B = 78f;

    static {
        NEAR.cell = 1;
        FAR.cell = 4;
    }

    private OceanRenderer() {}

    /** Dipakai mixin: air vanila permukaan dibuang dari chunk selama renderer ini sehat. */
    public static boolean cancelVanilla() {
        WaveConfig c = WaveConfig.get();
        return !failed && c.enabled && c.renderWaterMesh;
    }

    public static void render(WorldRenderContext ctx) {
        if (failed) return;
        WaveConfig cfg = WaveConfig.get();
        if (!cfg.enabled || !cfg.renderWaterMesh) return;
        ClientWorld world = ctx.world();
        if (world == null || ctx.consumers() == null || ctx.matrixStack() == null) return;
        try {
            if (world != lastWorld) {
                NEAR.clear();
                FAR.clear();
                lastWorld = world;
            }
            draw(ctx, world, cfg);
        } catch (Throwable t) {
            failed = true;
            OceanPhysicsMod.LOGGER.error("Mesh air dimatikan karena error", t);
            MinecraftClient mc = MinecraftClient.getInstance();
            try {
                if (mc.player != null) mc.player.sendMessage(Text.literal("Ocean Physics: mesh air MATI karena error: " + t), false);
                mc.execute(() -> { if (mc.worldRenderer != null) mc.worldRenderer.reload(); });
            } catch (Throwable ignored) {}
        }
    }

    private static void draw(WorldRenderContext ctx, ClientWorld world, WaveConfig cfg) {
        Vec3d cam = ctx.camera().getPos();
        boolean under = ctx.camera().getSubmersionType() == CameraSubmersionType.WATER;
        long time = world.getTime();
        long now = System.nanoTime();
        if (time != lastTime) {
            lastTime = time;
            lastNano = now;
        }
        float partial = Math.min(1f, (now - lastNano) / 50_000_000f);
        double t = (time + partial) / 20.0;
        double storm = WaveMath.storm(world);
        fTint = cfg.stormTint ? (float) (0.55 * storm) : 0f;
        budget = 500;

        Sprite sprite = MinecraftClient.getInstance().getBakedModelManager()
                .getBlockModels().getModel(Blocks.WATER.getDefaultState()).getParticleSprite();
        float u0 = sprite.getMinU(), u1 = sprite.getMaxU(), v0 = sprite.getMinV(), v1 = sprite.getMaxV();

        VertexConsumerProvider consumers = ctx.consumers();
        RenderLayer layer = RenderLayer.getTranslucentMovingBlock();
        VertexConsumer vc = consumers.getBuffer(layer);
        Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();

        int q = drawRing(world, cfg, FAR, FAR_HALF, false, vc, cam, time, t, storm, under, u0, u1, v0, v1, mat);
        q += drawRing(world, cfg, NEAR, NEAR_HALF, true, vc, cam, time, t, storm, under, u0, u1, v0, v1, mat);

        if (consumers instanceof VertexConsumerProvider.Immediate imm) imm.draw(layer);
        if (!announced && q > 0) {
            announced = true;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.sendMessage(Text.literal("Ocean Physics: permukaan laut aktif (" + q + " petak)"), true);
        }
    }

    private static double smooth(double d, double e0, double e1) {
        if (d <= e0) return 1.0;
        if (d >= e1) return 0.0;
        double f = (e1 - d) / (e1 - e0);
        return f * f * (3 - 2 * f);
    }

    private static int drawRing(ClientWorld world, WaveConfig cfg, WaterGrid g, int half, boolean near,
                                VertexConsumer vc, Vec3d cam, long time, double t, double storm, boolean under,
                                float u0, float u1, float v0, float v1, Matrix4f mat) {
        final int cell = g.cell, n = 2 * half + 1, m = n + 1;
        int gx0 = (int) Math.floor(cam.x / cell) - half;
        int gz0 = (int) Math.floor(cam.z / cell) - half;
        double ampTot = Math.max(0.2, 0.3 * cfg.waveSize.amplitude * WaveMath.boost(storm));
        double center = WaveMath.center(storm);
        double minLambda = near ? 4.5 : 18.0;
        double edge1 = half * (double) cell, edge0 = edge1 * (near ? 0.70 : 0.85);
        int baseAlpha = Math.max(0, Math.min(255, cfg.meshAlpha));

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int k = i * n + j;
                int gx = gx0 + i, gz = gz0 + j;
                int id = g.acquire(gx, gz);
                if (g.stale(id, time) && budget > 0) {
                    budget--;
                    fill(world, g, id, gx * cell, gz * cell, time);
                }
                ids[k] = id;
                if (!g.valid[id]) {
                    ys[k] = Float.NaN;
                    continue;
                }
                double x = (double) gx * cell, z = (double) gz * cell;
                double dx = x - cam.x, dz = z - cam.z;
                double d = Math.sqrt(dx * dx + dz * dz);
                double wave = (WaveMath.rawHeightLod(x, z, t, storm, minLambda) - center) * g.depth[id];
                float y = (float) (g.surface[id] + wave);
                if (!near) y -= (float) (0.35 * smooth(d, NEAR_HALF * 0.70, NEAR_HALF)); // di bawah cincin dekat: tanpa celah
                ys[k] = y;
                double cr = Math.max(0.0, Math.min(1.0, (wave - 0.30 * ampTot) / (0.45 * ampTot)));
                double dk = Math.max(0.0, Math.min(1.0, -wave / (0.5 * ampTot)));
                sh[k] = (float) (cr - 0.6 * dk);
            }
        }

        for (int ci = 0; ci < m; ci++) {
            for (int cj = 0; cj < m; cj++) {
                float sy = 0, ss = 0;
                int c = 0;
                for (int di = -1; di <= 0; di++) {
                    for (int dj = -1; dj <= 0; dj++) {
                        int i = ci + di, j = cj + dj;
                        if (i < 0 || j < 0 || i >= n || j >= n) continue;
                        int k = i * n + j;
                        if (Float.isNaN(ys[k])) continue;
                        sy += ys[k];
                        ss += sh[k];
                        c++;
                    }
                }
                int qd = ci * m + cj;
                if (c == 0) hy[qd] = Float.NaN;
                else {
                    hy[qd] = sy / c;
                    hs[qd] = ss / c;
                }
            }
        }
        for (int ci = 0; ci < m; ci++) {
            for (int cj = 0; cj < m; cj++) {
                int qd = ci * m + cj;
                float y = hy[qd];
                if (Float.isNaN(y)) continue;
                float xl = (ci > 0 && !Float.isNaN(hy[qd - m])) ? hy[qd - m] : y;
                float xr = (ci < m - 1 && !Float.isNaN(hy[qd + m])) ? hy[qd + m] : y;
                float zl = (cj > 0 && !Float.isNaN(hy[qd - 1])) ? hy[qd - 1] : y;
                float zr = (cj < m - 1 && !Float.isNaN(hy[qd + 1])) ? hy[qd + 1] : y;
                hnx[qd] = -(xr - xl) / (2f * cell);
                hnz[qd] = -(zr - zl) / (2f * cell);
            }
        }

        float cy = (float) -cam.y;
        int quads = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int k = i * n + j;
                if (Float.isNaN(ys[k])) continue;
                int a = i * m + j, b = a + 1, c2 = a + m + 1, d2 = a + m;
                if (Float.isNaN(hy[a]) || Float.isNaN(hy[b]) || Float.isNaN(hy[c2]) || Float.isNaN(hy[d2])) continue;
                int id = ids[k];
                float wx0 = (float) ((double) (gx0 + i) * cell - cam.x);
                float wz0 = (float) ((double) (gz0 + j) * cell - cam.z);
                float wx1 = wx0 + cell, wz1 = wz0 + cell;
                double mx = wx0 + cell * 0.5, mz = wz0 + cell * 0.5;
                double dm = Math.sqrt(mx * mx + mz * mz);
                if (!near && dm < NEAR_HALF * 0.6) continue; // sepenuhnya tertutup cincin dekat
                int alpha = (int) (baseAlpha * smooth(dm, edge0, edge1));
                if (alpha <= 2) continue;
                int rgb = g.rgb[id], light = g.light[id];
                if (!under) {
                    put(vc, mat, wx0, hy[a] + cy, wz0, u0, v0, rgb, alpha, hnx[a], hnz[a], hs[a], light, 1f);
                    put(vc, mat, wx0, hy[b] + cy, wz1, u0, v1, rgb, alpha, hnx[b], hnz[b], hs[b], light, 1f);
                    put(vc, mat, wx1, hy[c2] + cy, wz1, u1, v1, rgb, alpha, hnx[c2], hnz[c2], hs[c2], light, 1f);
                    put(vc, mat, wx1, hy[d2] + cy, wz0, u1, v0, rgb, alpha, hnx[d2], hnz[d2], hs[d2], light, 1f);
                } else { // kamera di bawah air: balik urutan titik supaya sisi bawah permukaan terlihat
                    put(vc, mat, wx0, hy[a] + cy, wz0, u0, v0, rgb, alpha, hnx[a], hnz[a], hs[a], light, -1f);
                    put(vc, mat, wx1, hy[d2] + cy, wz0, u1, v0, rgb, alpha, hnx[d2], hnz[d2], hs[d2], light, -1f);
                    put(vc, mat, wx1, hy[c2] + cy, wz1, u1, v1, rgb, alpha, hnx[c2], hnz[c2], hs[c2], light, -1f);
                    put(vc, mat, wx0, hy[b] + cy, wz1, u0, v1, rgb, alpha, hnx[b], hnz[b], hs[b], light, -1f);
                }
                quads++;
            }
        }
        return quads;
    }

    private static void put(VertexConsumer vc, Matrix4f mat, float x, float y, float z, float u, float v,
                            int rgb, int alpha, float nx, float nz, float shade, int light, float side) {
        float ny = (float) Math.sqrt(Math.max(0.0001, 1.0 - nx * nx - nz * nz));
        if (!(ny > 0f)) ny = 0.0001f;
        float inv = 1f / (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        if (shade > 0f) { // puncak ombak memutih (buih)
            float f = Math.min(1f, shade) * 0.6f;
            r = (int) (r + (255 - r) * f);
            g = (int) (g + (255 - g) * f);
            b = (int) (b + (255 - b) * f);
        } else if (shade < 0f) { // lembah menggelap
            float f = 1f + Math.max(-1f, shade) * 0.45f;
            r = (int) (r * f);
            g = (int) (g * f);
            b = (int) (b * f);
        }
        if (fTint > 0f) { // badai: air kelabu gelap
            r = (int) (r + (TINT_R - r) * fTint);
            g = (int) (g + (TINT_G - g) * fTint);
            b = (int) (b + (TINT_B - b) * fTint);
        }
        int a = Math.min(255, alpha + (int) (Math.max(0f, shade) * 40f));
        vc.vertex(mat, x, y, z)
                .color(r, g, b, a)
                .texture(u, v)
                .light(light)
                .normal(nx * inv * side, ny * inv * side, nz * inv * side);
    }

    private static void fill(ClientWorld world, WaterGrid g, int id, int x, int z, long time) {
        g.stamp[id] = time;
        g.valid[id] = false;
        if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) {
            g.stamp[id] = time - 90; // coba lagi sebentar lagi
            return;
        }
        double s = WaveMath.topWaterSurface(world, x, z);
        if (Double.isNaN(s)) return;
        BlockPos sp = new BlockPos(x, (int) Math.floor(s - 0.001), z);
        if (!world.getFluidState(sp).isStill()) return; // air mengalir tetap vanila
        g.surface[id] = (float) s;
        g.depth[id] = (float) WaveMath.depthFactor(world, x, s, z);
        BlockPos above = sp.up();
        g.light[id] = WorldRenderer.getLightmapCoordinates(world, above);
        g.rgb[id] = BiomeColors.getWaterColor(world, sp);
        g.valid[id] = true;
    }
}
