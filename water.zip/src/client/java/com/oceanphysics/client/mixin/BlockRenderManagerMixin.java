package com.oceanphysics.client.mixin;

import com.oceanphysics.client.OceanRenderer;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;
import net.minecraft.world.BlockRenderView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Air vanila permukaan (diam, terbuka ke langit) TIDAK lagi digambar di chunk: geometrinya digantikan permukaan
 * gelombang dinamis OceanRenderer. Air mengalir, air gua, dan air tertutup tetap vanila.
 */
@Mixin(BlockRenderManager.class)
public abstract class BlockRenderManagerMixin {
    @Inject(method = "renderFluid", at = @At("HEAD"), cancellable = true, require = 0)
    private void oceanphysics$noFlatWater(BlockPos pos, BlockRenderView world, VertexConsumer vc,
                                          BlockState bs, FluidState fs, CallbackInfo ci) {
        if (!OceanRenderer.cancelVanilla()) return;
        if (!fs.isIn(FluidTags.WATER) || !fs.isStill()) return;
        BlockPos up = pos.up();
        if (!world.getFluidState(up).isEmpty()) return;
        if (world.getLightLevel(LightType.SKY, up) < 12) return;
        ci.cancel();
    }
}
