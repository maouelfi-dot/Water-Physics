package com.oceanphysics.client;

import com.oceanphysics.FallingTreeEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;

/** Menggambar seluruh pohon (batang + daun) sebagai satu benda kaku yang berputar mengitari pangkalnya. */
public class FallingTreeRenderer extends EntityRenderer<FallingTreeEntity> {
    public FallingTreeRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
    }

    @Override
    public Identifier getTexture(FallingTreeEntity e) {
        return SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE;
    }

    @Override
    public boolean shouldRender(FallingTreeEntity e, Frustum frustum, double x, double y, double z) {
        return true; // kotak tabrak entity kecil, tapi pohonnya besar
    }

    @Override
    public void render(FallingTreeEntity e, float yaw, float tickDelta, MatrixStack m,
                       VertexConsumerProvider vcp, int light) {
        if (e.states.length == 0) return;
        double t = e.getWorld().getTime() - e.t0 + tickDelta;
        float ang = (float) Math.toRadians(FallingTreeEntity.angleDeg(t));
        BlockRenderManager brm = MinecraftClient.getInstance().getBlockRenderManager();
        m.push();
        m.multiply(new Quaternionf().rotationAxis(ang, (float) e.dirZ, 0f, (float) -e.dirX));
        for (int i = 0; i < e.states.length; i++) {
            int p = e.rel[i];
            m.push();
            m.translate(FallingTreeEntity.unX(p) - 0.5, FallingTreeEntity.unY(p), FallingTreeEntity.unZ(p) - 0.5);
            brm.renderBlockAsEntity(e.states[i], m, vcp, light, OverlayTexture.DEFAULT_UV);
            m.pop();
        }
        m.pop();
    }
}
