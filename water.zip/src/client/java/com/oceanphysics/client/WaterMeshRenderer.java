package com.oceanphysics.client;

import com.oceanphysics.OceanPhysicsMod;
import com.oceanphysics.WaterGrid;
import com.oceanphysics.WaveConfig;
import com.oceanphysics.WaveMath;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.text.Text;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Lapisan air dinamis di atas air vanilla: ombak (sinus) + riak (simulasi gelombang).
 * Selalu berada >= 0.04 blok DI ATAS permukaan vanilla, jadi tidak ada z-fighting/kedip.
 * Data kolom air disimpan di WaterGrid (array, tanpa HashMap) agar ringan di HP.
 * Dilindungi try/catch: jika ada error fitur ini mati sendiri dan game tidak crash.
 */
public final class WaterMeshRenderer {
    public static final WaterGrid GRID = new WaterGrid();
    private static final float BASE_OFFSET = 0.04f;

    private static ClientWorld lastWorld;
    private static boolean failed;
    private static long lastTime = Long.MIN_VALUE, lastNano;
    private static long shaderCheckTime = Long.MIN_VALUE / 2;
    private static boolean shaderCached;
    private static int refillBudget;

    private static float[] ys = new float[0], sh = new float[0];
    private static float[] hy = new float[0], hs = new float[0], hnx = new float[0], hnz = new float[0];
    private static int[] ids = new int[0];
    private static boolean announced;
    private static float[] fo = new float[0], hf = new float[0];
    private static float fSkyR = 120f, fSkyG = 160f, fSkyB = 220f;
    private static Identifier foamId;
    private static boolean foamTried;

    // konstanta per frame untuk warna badai dan silau (diisi di draw())
    private static float fTint, fGlare, fLx, fLy, fLz;
    private static final float TINT_R = 52f, TINT_G = 74f, TINT_B = 78f;

    private WaterMeshRenderer() {}

    /** Dipanggil dari tick client: samakan ukuran sel dan bersihkan saat ganti dunia. */
    public static void syncWorld(ClientWorld world, WaveConfig cfg) {
        if (world != lastWorld) {
            GRID.clear();
            lastWorld = world;
        }
        int cell = Math.max(1, Math.min(4, cfg.meshCell));
        if (GRID.cell != cell) {
            GRID.cell = cell;
            GRID.clear();
        }
    }

    public static void render(WorldRenderContext ctx) {
        if (failed) return;
        WaveConfig cfg = WaveConfig.get();
        if (!cfg.enabled || !cfg.renderWaterMesh) return;
        ClientWorld world = ctx.world();
        if (world == null || ctx.consumers() == null || ctx.matrixStack() == null) return;
        if (!cfg.meshWithShaders && shadersActive(world.getTime())) return;
        try {
            syncWorld(world, cfg);
            draw(ctx, world, cfg);
        } catch (Throwable t) {
            failed = true;
            OceanPhysicsMod.LOGGER.error("Mesh air dimatikan karena error", t);
            try {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null) mc.player.sendMessage(Text.literal("Water Physics: mesh air MATI karena error: " + t), false);
            } catch (Throwable ignored) {}
        }
    }

    private static boolean shadersActive(long time) {
        if (time - shaderCheckTime < 20) return shaderCached;
        shaderCheckTime = time;
        if (!FabricLoader.getInstance().isModLoaded("iris")) {
            shaderCached = false;
            return false;
        }
        try {
            Class<?> c = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object api = c.getMethod("getInstance").invoke(null);
            shaderCached = (Boolean) c.getMethod("isShaderPackInUse").invoke(api);
        } catch (Throwable t) {
            shaderCached = true;
        }
        return shaderCached;
    }

    private static double soft(double x) {
        final double L = 0.06; // angkat sedikit di atas air vanila; lembah dimampatkan, tidak pernah menembus vanila
        return x >= 0 ? L + x : L * Math.exp(x / L);
    }

    private static void draw(WorldRenderContext ctx, ClientWorld world, WaveConfig cfg) {
        final int cell = GRID.cell;
        final int half = Math.max(4, Math.min(30, cfg.meshRadius / cell));
        final int n = 2 * half + 1, m = n + 1;
        Vec3d cam = ctx.camera().getPos();

        long time = world.getTime();
        long now = System.nanoTime();
        if (time != lastTime) {
            lastTime = time;
            lastNano = now;
        }
        float partial = Math.min(1f, (now - lastNano) / 50_000_000f);
        double t = (time + partial) / 20.0;

        if (ys.length != n * n) {
            ys = new float[n * n];
            sh = new float[n * n];
            ids = new int[n * n];
            hy = new float[m * m];
            hs = new float[m * m];
            hnx = new float[m * m];
            hnz = new float[m * m];
            fo = new float[n * n];
            hf = new float[m * m];
        }

        int gx0 = (int) Math.floor(cam.x / cell) - half;
        int gz0 = (int) Math.floor(cam.z / cell) - half;
        refillBudget = 220;
        double edge1 = half * (double) cell;
        double edge0 = edge1 * 0.65;
        int baseAlpha = Math.max(0, Math.min(255, cfg.meshAlpha));
        final double storm = WaveMath.storm(world);
        double amp = Math.max(0.05, cfg.waveSize.amplitude * WaveMath.boost(storm));
        setupFrame(world, cfg, storm, cam, partial);

        // 1) tinggi tiap sel (pusat blok)
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int k = i * n + j;
                int gx = gx0 + i, gz = gz0 + j;
                int id = GRID.acquire(gx, gz);
                if (GRID.stale(id, time) && refillBudget > 0) {
                    refillBudget--;
                    fill(world, id, gx * cell, gz * cell, time);
                }
                ids[k] = id;
                if (!GRID.valid[id]) {
                    ys[k] = Float.NaN;
                    fo[k] = 0f;
                    continue;
                }
                double x = (double) gx * cell, z = (double) gz * cell;
                double dx = x - cam.x, dz = z - cam.z;
                double d = Math.sqrt(dx * dx + dz * dz);
                double fade;
                if (d <= edge0) fade = 1;
                else if (d >= edge1) fade = 0;
                else {
                    double f = (edge1 - d) / (edge1 - edge0);
                    fade = f * f * (3 - 2 * f);
                }
                double wave = WaveMath.rawHeight(x, z, t, storm) * GRID.depth[id];
                double total = (wave + GRID.h[id]) * fade;
                ys[k] = (float) (GRID.surface[id] + BASE_OFFSET + soft(total));
                float cr = (float) Math.max(0.0, Math.min(1.0, (total / amp - (0.5 - 0.2 * storm)) * 2.0));
                float dk = (float) Math.max(0.0, Math.min(1.0, -total / 0.25));
                sh[k] = cr - dk;
                fo[k] = Math.max(0f, cr);
            }
        }

        // 1b) buih tepi pantai: sel air yang bersebelahan dengan darat/air lain berdenyut seperti ombak menyapu pantai
        for (int i = 1; i < n - 1; i++) {
            for (int j = 1; j < n - 1; j++) {
                int k = i * n + j;
                if (Float.isNaN(ys[k])) continue;
                if (Float.isNaN(ys[k - n]) || Float.isNaN(ys[k + n]) || Float.isNaN(ys[k - 1]) || Float.isNaN(ys[k + 1])) {
                    float pulse = (float) (0.55 + 0.45 * Math.sin(t * 1.3 + (gx0 + i + gz0 + j) * 0.45));
                    fo[k] = Math.max(fo[k], pulse);
                }
            }
        }

        // 2) titik sudut = rata-rata sel yang menyentuhnya (permukaan halus, rata dengan dinding/pantai)
        for (int ci = 0; ci < m; ci++) {
            for (int cj = 0; cj < m; cj++) {
                float sy = 0, ss = 0, sf = 0;
                int c = 0;
                for (int di = -1; di <= 0; di++) {
                    for (int dj = -1; dj <= 0; dj++) {
                        int i = ci + di, j = cj + dj;
                        if (i < 0 || j < 0 || i >= n || j >= n) continue;
                        int k = i * n + j;
                        if (Float.isNaN(ys[k])) continue;
                        sy += ys[k];
                        ss += sh[k];
                        sf += fo[k];
                        c++;
                    }
                }
                int q = ci * m + cj;
                if (c == 0) hy[q] = Float.NaN;
                else {
                    hy[q] = sy / c;
                    hs[q] = ss / c;
                    hf[q] = sf / c;
                }
            }
        }
        for (int ci = 0; ci < m; ci++) {
            for (int cj = 0; cj < m; cj++) {
                int q = ci * m + cj;
                float y = hy[q];
                if (Float.isNaN(y)) continue;
                float xl = (ci > 0 && !Float.isNaN(hy[q - m])) ? hy[q - m] : y;
                float xr = (ci < m - 1 && !Float.isNaN(hy[q + m])) ? hy[q + m] : y;
                float zl = (cj > 0 && !Float.isNaN(hy[q - 1])) ? hy[q - 1] : y;
                float zr = (cj < m - 1 && !Float.isNaN(hy[q + 1])) ? hy[q + 1] : y;
                float nx = -(xr - xl) / (2f * cell);
                float nz = -(zr - zl) / (2f * cell);
                float len = (float) Math.sqrt(nx * nx + 1f + nz * nz);
                hnx[q] = nx / len;
                hnz[q] = nz / len;
            }
        }

        Sprite sprite = MinecraftClient.getInstance().getBakedModelManager()
                .getBlockModels().getModel(Blocks.WATER.getDefaultState()).getParticleSprite();
        float u0 = sprite.getMinU(), u1 = sprite.getMaxU(), v0 = sprite.getMinV(), v1 = sprite.getMaxV();

        VertexConsumerProvider consumers = ctx.consumers();
        RenderLayer layer = RenderLayer.getEntityTranslucent(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE);
        VertexConsumer vc = consumers.getBuffer(layer);
        Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
        float cy = (float) -cam.y;
        int quads = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int k = i * n + j;
                if (Float.isNaN(ys[k])) continue;
                int a = i * m + j, b = a + 1, c2 = a + m + 1, d2 = a + m;
                if (Float.isNaN(hy[a]) || Float.isNaN(hy[b]) || Float.isNaN(hy[c2]) || Float.isNaN(hy[d2])) continue;
                int id = ids[k];
                float wx0 = (float) ((double) (gx0 + i) * cell - cam.x);
                float wz0 = (float) ((double) (gz0 + j) * cell - cam.z);
                float wx1 = wx0 + cell, wz1 = wz0 + cell;
                double mx = wx0 + cell * 0.5, mz = wz0 + cell * 0.5;
                double dm = Math.sqrt(mx * mx + mz * mz);
                float af = dm <= edge0 ? 1f : (dm >= edge1 ? 0f : (float) ((edge1 - dm) / (edge1 - edge0)));
                int alpha = (int) (baseAlpha * af);
                if (alpha <= 2) continue;
                put(vc, mat, wx0, hy[a] + cy, wz0, u0, v0, id, alpha, hnx[a], hnz[a], hs[a]);
                put(vc, mat, wx0, hy[b] + cy, wz1, u0, v1, id, alpha, hnx[b], hnz[b], hs[b]);
                put(vc, mat, wx1, hy[c2] + cy, wz1, u1, v1, id, alpha, hnx[c2], hnz[c2], hs[c2]);
                put(vc, mat, wx1, hy[d2] + cy, wz0, u1, v0, id, alpha, hnx[d2], hnz[d2], hs[d2]);
                quads++;
            }
        }

        if (consumers instanceof VertexConsumerProvider.Immediate imm) {
            imm.draw(layer);
        }

        // lapisan buih bertekstur (renang di atas mesh air, sedikit lebih tinggi)
        if (cfg.foam && cfg.foamLayer) {
            Identifier ft = foamTexture();
            if (ft != null) {
                RenderLayer fl = RenderLayer.getEntityTranslucent(ft);
                VertexConsumer fcons = consumers.getBuffer(fl);
                final double per = 6.0; // 1 ulangan tekstur = 6 blok
                double ua = (t * 0.02) % 1.0, va = (t * 0.013) % 1.0;
                float fint = (float) cfg.foamIntensity;
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        int k = i * n + j;
                        if (Float.isNaN(ys[k])) continue;
                        int a = i * m + j, b = a + 1, c2 = a + m + 1, d2 = a + m;
                        if (Float.isNaN(hy[a]) || Float.isNaN(hy[b]) || Float.isNaN(hy[c2]) || Float.isNaN(hy[d2])) continue;
                        float fa = hf[a] * fint, fb = hf[b] * fint, fcc = hf[c2] * fint, fd = hf[d2] * fint;
                        if (Math.max(Math.max(fa, fb), Math.max(fcc, fd)) < 0.04f) continue;
                        float wx0 = (float) ((double) (gx0 + i) * cell - cam.x);
                        float wz0 = (float) ((double) (gz0 + j) * cell - cam.z);
                        float wx1 = wx0 + cell, wz1 = wz0 + cell;
                        double mx = wx0 + cell * 0.5, mz = wz0 + cell * 0.5;
                        double dm = Math.sqrt(mx * mx + mz * mz);
                        float af = dm <= edge0 ? 1f : (dm >= edge1 ? 0f : (float) ((edge1 - dm) / (edge1 - edge0)));
                        if (af <= 0.02f) continue;
                        double bx = (double) (gx0 + i) * cell, bz = (double) (gz0 + j) * cell;
                        float fu0 = (float) (((bx / per + ua) % 1.0 + 1.0) % 1.0);
                        float fv0 = (float) (((bz / per + va) % 1.0 + 1.0) % 1.0);
                        float fu1 = fu0 + (float) (cell / per), fv1 = fv0 + (float) (cell / per);
                        int id = ids[k];
                        float yo = cy + 0.02f;
                        putFoam(fcons, mat, wx0, hy[a] + yo, wz0, fu0, fv0, id, foamAlpha(fa, af));
                        putFoam(fcons, mat, wx0, hy[b] + yo, wz1, fu0, fv1, id, foamAlpha(fb, af));
                        putFoam(fcons, mat, wx1, hy[c2] + yo, wz1, fu1, fv1, id, foamAlpha(fcc, af));
                        putFoam(fcons, mat, wx1, hy[d2] + yo, wz0, fu1, fv0, id, foamAlpha(fd, af));
                    }
                }
                if (consumers instanceof VertexConsumerProvider.Immediate imm2) {
                    imm2.draw(fl);
                }
            }
        }
        if (!announced && quads > 0) {
            announced = true;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.sendMessage(Text.literal("Water Physics: mesh air aktif (" + quads + " petak)"), true);
        }
    }

    /** Warna badai dan arah cahaya (matahari/bulan) untuk silau, sekali per frame. */
    private static void setupFrame(ClientWorld world, WaveConfig cfg, double storm, Vec3d cam, float partial) {
        try { // warna langit saat ini (siang/malam/hujan) untuk pantulan Fresnel
            Vec3d sk = world.getSkyColor(cam, partial);
            fSkyR = (float) (sk.x * 255.0);
            fSkyG = (float) (sk.y * 255.0);
            fSkyB = (float) (sk.z * 255.0);
        } catch (Throwable e) {
            fSkyR = 120f; fSkyG = 160f; fSkyB = 220f;
        }
        fTint = cfg.stormTint ? (float) (0.55 * storm) : 0f;
        fGlare = 0f;
        if (!cfg.glare) return;
        double d = world.getTimeOfDay() / 24000.0 - 0.25;
        d = d - Math.floor(d);
        double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
        double a = ((d * 2.0 + e) / 3.0) * Math.PI * 2.0; // sudut langit (rad); siang = 0
        double sx = -Math.sin(a), sy = Math.cos(a);
        double rain = world.getRainGradient(1.0f);
        double calm = 1.0 - 0.85 * rain; // awan/hujan meredam silau
        double inten;
        if (sy > -0.12) {
            inten = Math.max(0.0, Math.min(1.0, (sy + 0.12) / 0.3));
            fLx = (float) sx;
            fLy = (float) sy;
        } else { // malam: pantulan bulan, lebih redup
            inten = 0.3 * Math.max(0.0, Math.min(1.0, (-sy - 0.05) / 0.3));
            fLx = (float) -sx;
            fLy = (float) -sy;
        }
        fLz = 0f;
        fGlare = (float) (inten * calm * cfg.glareStrength);
    }

    private static int clamp255(float v) {
        return v < 0f ? 0 : (v > 255f ? 255 : (int) v);
    }

    private static int foamAlpha(float f, float af) {
        return clamp255(Math.min(1f, f) * 230f * af);
    }

    private static void putFoam(VertexConsumer vc, Matrix4f mat, float x, float y, float z,
                                float u, float v, int id, int alpha) {
        vc.vertex(mat, x, y, z)
                .color(255, 255, 255, alpha)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(GRID.light[id])
                .normal(0f, 1f, 0f);
    }

    private static void put(VertexConsumer vc, Matrix4f mat, float x, float y, float z,
                            float u, float v, int id, int alpha, float nx, float nz, float shade) {
        WaveConfig cfg = WaveConfig.get();
        float ny = (float) Math.sqrt(Math.max(0.0001, 1.0 - nx * nx - nz * nz));
        int c = GRID.rgb[id];
        float r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        float dep = GRID.depth[id];
        if (cfg.depthTint) { // perairan dalam lebih gelap dan pekat, dangkal lebih terang dan bening
            float dk = 1f - 0.30f * dep;
            r *= dk;
            g *= dk;
            b *= dk;
        }
        if (shade > 0f) {          // puncak ombak memutih
            float f = Math.min(1f, shade) * 0.6f;
            r += (255f - r) * f;
            g += (255f - g) * f;
            b += (255f - b) * f;
        } else if (shade < 0f) {   // lembah/riak tekanan menggelap
            float f = 1f + Math.max(-1f, shade) * 0.45f;
            r *= f;
            g *= f;
            b *= f;
        }
        if (fTint > 0f) { // badai: air kelabu gelap
            r += (TINT_R - r) * fTint;
            g += (TINT_G - g) * fTint;
            b += (TINT_B - b) * fTint;
        }
        // vektor ke kamera (x,y,z sudah relatif kamera)
        float len = (float) Math.sqrt(x * x + y * y + z * z);
        float vx = 0f, vy = 1f, vz = 0f, ndv = 1f;
        if (len > 0.05f) {
            vx = -x / len;
            vy = -y / len;
            vz = -z / len;
            ndv = nx * vx + ny * vy + nz * vz;
        }
        float fres = 0f;
        if (cfg.fresnel && len > 0.05f) { // pantulan langit: makin landai sudut pandang, makin memantul
            float q = 1f - Math.max(0f, Math.min(1f, ndv));
            float q2 = q * q;
            fres = Math.min(0.85f, 0.03f + 0.8f * q2 * q2);
            r += (fSkyR - r) * fres;
            g += (fSkyG - g) * fres;
            b += (fSkyB - b) * fres;
        }
        if (fGlare > 0f && len > 0.05f && ndv > 0f) { // silau matahari/bulan (Phong)
            float rx = 2f * ndv * nx - vx, ry = 2f * ndv * ny - vy, rz = 2f * ndv * nz - vz;
            float rl = rx * fLx + ry * fLy + rz * fLz;
            if (rl > 0.6f) {
                float p2 = rl * rl, p4 = p2 * p2, p8 = p4 * p4, p16 = p8 * p8, p32 = p16 * p16;
                float spec = p32 * p16 * fGlare * (1.6f - ndv);
                if (spec > 0.003f) {
                    float f = Math.min(1f, spec);
                    r += (255f - r) * f;
                    g += (250f - g) * f;
                    b += (235f - b) * f;
                    shade = Math.max(shade, f * 0.5f);
                }
            }
        }
        float aF = alpha * (cfg.depthTint ? (0.8f + 0.2f * dep) : 1f) + fres * 110f + Math.max(0f, shade) * 40f;
        vc.vertex(mat, x, y, z)
                .color(clamp255(r), clamp255(g), clamp255(b), clamp255(aF))
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(GRID.light[id])
                .normal(nx, ny, nz);
    }

    /** Tekstur buih prosedural (noise periodik, bisa diulang mulus). Dibuat sekali; null jika gagal. */
    private static Identifier foamTexture() {
        if (foamId != null || foamTried) return foamId;
        foamTried = true;
        try {
            final int size = 128;
            NativeImage img = new NativeImage(NativeImage.Format.RGBA, size, size, false);
            java.util.Random rnd = new java.util.Random(7331L);
            int[] lat = {8, 16, 32};
            float[] wgt = {0.5f, 0.3f, 0.2f};
            float[][] grids = new float[3][];
            for (int o = 0; o < 3; o++) {
                grids[o] = new float[lat[o] * lat[o]];
                for (int q = 0; q < grids[o].length; q++) grids[o][q] = rnd.nextFloat();
            }
            for (int py = 0; py < size; py++) {
                for (int px = 0; px < size; px++) {
                    float nv = 0f;
                    for (int o = 0; o < 3; o++) {
                        int L = lat[o];
                        float fx = (float) px / size * L, fy = (float) py / size * L;
                        int ix = (int) fx, iy = (int) fy;
                        float tx = fx - ix, ty = fy - iy;
                        tx = tx * tx * (3f - 2f * tx);
                        ty = ty * ty * (3f - 2f * ty);
                        int x0 = ix % L, x1 = (ix + 1) % L, y0 = iy % L, y1 = (iy + 1) % L;
                        float v00 = grids[o][y0 * L + x0], v10 = grids[o][y0 * L + x1];
                        float v01 = grids[o][y1 * L + x0], v11 = grids[o][y1 * L + x1];
                        float top = v00 + (v10 - v00) * tx, bot = v01 + (v11 - v01) * tx;
                        nv += wgt[o] * (top + (bot - top) * ty);
                    }
                    float al = Math.max(0f, Math.min(1f, (nv - 0.52f) / 0.20f));
                    al = al * al * (3f - 2f * al);
                    int ai = (int) (al * 255f);
                    img.setColor(px, py, (ai << 24) | 0x00FFFFFF);
                }
            }
            NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
            Identifier id = Identifier.of("oceanphysics", "dynamic/foam");
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
            foamId = id;
        } catch (Throwable t) {
            OceanPhysicsMod.LOGGER.error("Tekstur buih gagal dibuat, lapisan buih dimatikan", t);
        }
        return foamId;
    }

    private static void fill(ClientWorld world, int id, int x, int z, long time) {
        GRID.stamp[id] = time;
        GRID.valid[id] = false;
        if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) {
            GRID.stamp[id] = time - 90; // coba lagi sebentar lagi
            return;
        }
        double s = WaveMath.topWaterSurface(world, x, z);
        if (Double.isNaN(s)) return;
        GRID.surface[id] = (float) s;
        GRID.depth[id] = (float) WaveMath.depthFactor(world, x, s, z); // sudah termasuk faktor air mengalir
        BlockPos above = new BlockPos(x, (int) Math.floor(s) + 1, z);
        GRID.light[id] = WorldRenderer.getLightmapCoordinates(world, above);
        GRID.rgb[id] = BiomeColors.getWaterColor(world, above.down());
        GRID.valid[id] = true;
    }
}
