# Ocean Physics v9.0.0

## Yang berubah
- Semua sistem air lama dihapus (air bermassa, tumpahan, riak, busa, erosi, mesh lapis lama).
- Air vanila permukaan (diam, terbuka ke langit) tidak digambar lagi di chunk; diganti permukaan gelombang dinamis (OceanRenderer) dengan 10 gelombang acak + modulasi, tinggi sampai ±2-4 blok di laut dalam (config waveSize: SMALL/MEDIUM/LARGE).
- Kapal dan pemain terangkat mengikuti ombak. Air mengalir/gua tetap vanila.
- Pohon tumbang utuh (batang + daun) lalu hancur dan drop saat menyentuh tanah (FallingTreeEntity).

## Catatan
- Kalau Sodium memakai renderer air sendiri, pembatalan air vanila tidak berlaku (air vanila tetap tergambar).
- Config: .minecraft/config/oceanphysics.json (config lama otomatis diganti).

## v9.0.1 — rumus ombak gaya Physics Mod
- Ombak sekarang memakai rumus iteratif ala Physics Mod (exp(sin) + domain warp), tinggi terpusat di permukaan vanila (naik dan turun).
- `shader-integration/ocean_wave.glsl`: versi GLSL rumus yang sama untuk ditempel ke shader pack buatanmu.
