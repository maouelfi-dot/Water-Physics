// Port GLSL dari rumus ombak di WaveMath.java (gaya Physics Mod). Tempel ke gbuffers_water.vsh shader kamu
// kalau mau tinggi ombak di shader SAMA dengan fisika kapal/pemain di mod.
// t = waktu dunia dalam detik (bukan frameTimeCounter) * waveSpeed(0.8) * 0.45. amplitude = ukuran ombak (LARGE=8.5).
const float OW_F0 = 3.5, OW_XZ = 0.035, OW_DRAG = 0.048, OW_WEIGHT = 0.8, OW_FMULT = 1.18, OW_SMULT = 1.07, OW_INC = 12.0, OW_S0 = 2.0;
float oceanWave(vec2 worldXZ, float t, int iters) {
    vec2 p = worldXZ * OW_XZ;
    float it = 0.0, freq = OW_F0, sp = OW_S0, wt = 1.0, w = 0.0, ws = 0.0;
    for (int i = 0; i < iters; i++) {
        vec2 d = vec2(sin(it), cos(it));
        float ph = dot(d, p) * freq + t * sp;
        float wv = exp(sin(ph) - 1.0);
        p -= d * (wv * cos(ph)) * wt * OW_DRAG;
        w += wv * wt; ws += wt;
        wt *= OW_WEIGHT; freq *= OW_FMULT; sp *= OW_SMULT; it += OW_INC;
    }
    return w / ws;                       // 0.18..0.86, rata-rata 0.465
}
// tinggi (blok) di atas/bawah permukaan vanila: (oceanWave(...) - 0.465) * amplitude * depthFactor
